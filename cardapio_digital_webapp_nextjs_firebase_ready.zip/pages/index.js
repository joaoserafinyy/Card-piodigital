export default function Home() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-3xl font-bold">Bem-vindo ao Cardápio Digital</h1>
    </div>
  );
}
